
import React, { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, ScrollView } from 'react-native';
import { NetworkInfo } from 'react-native-network-info';
import { createServer } from 'http';

export default function App() {
  const [ip, setIp] = useState('');
  const [status, setStatus] = useState('Aguardando imagem...');
  const [imgData, setImgData] = useState(null);

  useEffect(() => {
    NetworkInfo.getIPV4Address().then(setIp);

    const server = createServer((req, res) => {
      if (req.method === 'POST' && req.url === '/upload') {
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', () => {
          try {
            const json = JSON.parse(body);
            const base64 = json.image;
            setImgData('data:image/jpeg;base64,' + base64);

            const detected = Math.random() > 0.5; // Simulação de IA
            setStatus(detected ? 'Pessoa detectada!' : 'Nenhuma pessoa detectada.');

            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ result: detected ? 'Pessoa detectada!' : 'Nenhuma pessoa detectada.' }));
          } catch (e) {
            res.writeHead(400);
            res.end('Erro ao processar imagem.');
          }
        });
      } else {
        res.writeHead(200);
        res.end('Servidor rodando...');
      }
    });

    server.listen(5000, () => console.log('Servidor rodando na porta 5000'));
    return () => server.close();
  }, []);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>IP do celular:</Text>
      <Text style={styles.ip}>{ip}:5000</Text>
      {imgData && <Image source={{ uri: imgData }} style={styles.image} />}
      <Text style={styles.status}>{status}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  title: { fontSize: 20, fontWeight: 'bold', marginTop: 40 },
  ip: { fontSize: 18, marginBottom: 20 },
  image: { width: 300, height: 240, marginVertical: 20, borderRadius: 10 },
  status: { fontSize: 20, fontWeight: 'bold', color: '#0a84ff' }
});
